package com.xander.catfacts.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.xander.catfacts.R
import com.xander.catfacts.constant.ArgumentConstants
import com.xander.catfacts.databinding.FragmentShowFactsBinding
import com.xander.catfacts.model.CatFact
import com.xander.catfacts.ui.fragment.base.BaseFragment
import com.xander.catfacts.ui.viewmodel.ShowFactsViewModel
import org.koin.android.viewmodel.ext.android.viewModel
import org.koin.core.parameter.parametersOf

class ShowFactsFragment : BaseFragment() {

    private lateinit var mBinding: FragmentShowFactsBinding

    companion object {
        const val TAG = "ShowFactsFragment"
        fun newInstance(factsList: ArrayList<CatFact>): ShowFactsFragment {
            val fragment = ShowFactsFragment()
            val args = Bundle()
            args.putParcelableArrayList(ArgumentConstants.ARRAY_FACTS_DATA, factsList)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_show_facts, container, false)

        val viewModel by viewModel<ShowFactsViewModel> {
            parametersOf(arguments!!.getParcelableArrayList<CatFact>(ArgumentConstants.ARRAY_FACTS_DATA))
        }

        mBinding.viewModel = viewModel

        return mBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mBinding.viewModel?.liveDataShowDialogWithFact?.observe(viewLifecycleOwner, Observer {
            Toast.makeText(context, it.fact, Toast.LENGTH_SHORT).show()
        })
    }
}