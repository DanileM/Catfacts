package com.xander.catfacts.constant

class UrlConstants {

    companion object{
        const val PICTURE_URL = "https://aws.random.cat/"
        const val FACT_URL = "https://cat-fact.herokuapp.com/"
    }

}