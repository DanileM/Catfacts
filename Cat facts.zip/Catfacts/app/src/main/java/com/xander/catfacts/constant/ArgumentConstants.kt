package com.xander.catfacts.constant

class ArgumentConstants {

    companion object{
        const val ARRAY_FACTS_DATA = "array_facts_data"
    }

}