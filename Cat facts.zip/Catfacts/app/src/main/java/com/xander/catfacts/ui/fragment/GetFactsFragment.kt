package com.xander.catfacts.ui.fragment

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.xander.catfacts.R
import com.xander.catfacts.databinding.FragmentGetFactsBinding
import com.xander.catfacts.model.CatFact
import com.xander.catfacts.ui.fragment.base.BaseFragment
import com.xander.catfacts.ui.viewmodel.GetFactsViewModel
import org.koin.android.viewmodel.ext.android.viewModel


class GetFactsFragment : BaseFragment() {

    private lateinit var mBinding: FragmentGetFactsBinding

    companion object {
        const val TAG = "GetFactsFragment"
        fun newInstance(): GetFactsFragment {
            val fragment = GetFactsFragment()
            val args = Bundle()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_get_facts, container, false)

        val viewModel by viewModel<GetFactsViewModel>()
        mBinding.viewModel = viewModel

        return mBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mBinding.viewModel?.liveDataShowFacts?.observe(viewLifecycleOwner, Observer {
            (baseFragmentContract as GetFactsFragmentContract).showFacts(it)
        })
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        baseFragmentContract = context as GetFactsFragmentContract
    }

    interface GetFactsFragmentContract : BaseFragmentContract {
        fun showFacts(factsList: ArrayList<CatFact>)
    }
}