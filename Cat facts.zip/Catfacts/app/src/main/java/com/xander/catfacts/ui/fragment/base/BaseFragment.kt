package com.xander.catfacts.ui.fragment.base

import androidx.fragment.app.Fragment

abstract class BaseFragment : Fragment() {

    open var baseFragmentContract: BaseFragmentContract? = null

    override fun onDetach() {
        super.onDetach()
        baseFragmentContract = null
    }

    interface BaseFragmentContract
}