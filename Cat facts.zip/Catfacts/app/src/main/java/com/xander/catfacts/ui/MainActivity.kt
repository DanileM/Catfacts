package com.xander.catfacts.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.xander.catfacts.R
import com.xander.catfacts.model.CatFact
import com.xander.catfacts.ui.fragment.GetFactsFragment
import com.xander.catfacts.ui.fragment.ShowFactsFragment

class MainActivity : AppCompatActivity(), GetFactsFragment.GetFactsFragmentContract {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        transactionFragmentWithStack(GetFactsFragment.newInstance(), GetFactsFragment.TAG)
    }

    private fun transactionFragmentWithStack(fragment: Fragment, tag: String) {
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.container, fragment)
            .addToBackStack(tag)
            .commitAllowingStateLoss()
    }

    override fun showFacts(factsList: ArrayList<CatFact>) {
        transactionFragmentWithStack(ShowFactsFragment.newInstance(factsList), ShowFactsFragment.TAG)
    }
}
