package com.xander.catfacts.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CatFact(var picture: String = "", var fact: String = "") : Parcelable