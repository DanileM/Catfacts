package com.xander.catfacts.ui.viewmodel

import androidx.databinding.Bindable
import androidx.databinding.library.baseAdapters.BR
import androidx.lifecycle.MutableLiveData
import com.xander.catfacts.api.FactServiceApi
import com.xander.catfacts.api.PictureServiceApi
import com.xander.catfacts.model.CatFact
import com.xander.catfacts.ui.viewmodel.base.BaseViewModel
import kotlinx.coroutines.*

class GetFactsViewModel(
    private val pictureServiceApi: PictureServiceApi,
    private val factServiceApi: FactServiceApi,
    private val coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) : BaseViewModel() {

    private val catFactsList = arrayListOf<CatFact>()
    var liveDataShowFacts = MutableLiveData<ArrayList<CatFact>>()

    private var isListNotFull = true

    @Bindable
    var enabledButton = true
        set(value) {
            field = value
            notifyPropertyChanged(BR.enabledButton)
        }

    fun getFacts() {
        enabledButton = false
        coroutineScope.launch {
            while (isListNotFull) {
                var catFact = CatFact()
                try {
                    val responsePicture = pictureServiceApi.getPicture().await()
                    catFact.picture = responsePicture.picture

                    val responseFact = factServiceApi.getFact().await()
                    catFact.fact = responseFact.fact

                    catFactsList.add(catFact)

                    checkIsListFull()
                } catch (e: Exception) {
                    //handle error
                    enabledButton = true
                }
            }
        }

    }

    private fun checkIsListFull(){
        if(catFactsList.size == 10) {
            isListNotFull = false
            liveDataShowFacts.postValue(catFactsList)
        } else
            isListNotFull = true
    }

    override fun onCleared() {
        super.onCleared()
        coroutineScope.coroutineContext.cancel()
    }

}